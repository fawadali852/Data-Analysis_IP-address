import pandas as pd
import numpy as np
Network_ds = pd.read_csv(
    r'C:\Users\User\Documents\packets networking\Train_Test_Network.csv')
# output = Network_ds.tolist()
# print(output)
srcip = Network_ds['src_ip']
destip = Network_ds['dst_ip']
labels = Network_ds['label']
print(range(len(Network_ds)))
# print(heading)
for i in range(len(Network_ds)):
 if(srcip[i]==destip[i]):
    if(labels[i]==1):
     print('The ip that are same {i+2}', srcip[i],' and ',destip[i],'on label',labels[i])
    

# if(srcip.equals(destip)):
# limit = len(Network_ds)
# print(limit)
# i=2
# for i in range(0,132):
# if(srcip[i]==(destip[i])):
#     print(i,"They are same",srcip," ",destip)
# else:
#     print(i,"they are not same \n src IP: ", srcip,"dest IP: ",destip)
    
    
# for i in range(Network_ds):
#     if srcip == destip:


# print(labels==True)

# TO GET THE TYPE OF COLUMNS
# print(type(Network_ds.src_ip[0]))
# size = len(labels)
# print("the size of labels: ", size)
# for w in output:
#     if(w==1):
#         for y in range(size):
#             print("labels: ",w,"no. ",y)
# lab = Network_ds.loc[[2,50]].label 
# if(lab==1): 
#   print(lab)

# TO COMPARE THE IPS
# for x in labels:
#     for y in range(size):
#         if (x == 1):
#             if (Network_ds.src_ip[y] != Network_ds.dst_ip[y]):
#                 # df=pd.DataFrame(
#                 #   {  'Network_ds.src_ip':[Network_ds.src_ip[y]],
#                 #     'Network_ds.dst_ip':Network_ds.dst_ip[y]
#                 #   }
#                 # )
#                 # df.to_csv('file.csv')
#                 print(y,
#                     "The src ip:", Network_ds.src_ip[y], "The dest ip: ", Network_ds.dst_ip[y])
#         y+=1
#         break

                

    # if(Network_ds.type[x]==1):
    #  print("It contains 1")
    # else:
    #     print("it doesnt contain 1")


# NO USE OF THESE CODE
#     print("srcip:", srcip)
# else:
#     print("destip", destip)


# print(labels)
# if (labels=='1'):
#     print(srcip)
# if (Network_ds['label'] == '1'):
#     print(srcip +' '+ destip)
############################################################3
### CSV LIBRARY ###################
# import csv
# network = csv.reader(
#     r'C:\Users\User\Documents\packets networking\testcsvdata.csv')



##CHAT GP
# col_name= next(network)
# for row in network:
#     row.append(row)
# print(col_name)
# print(row)
# print(range(rows))
# for i in range(rows):
#     for j in range(rows):
#         if i == j:
#             continue
#         else:
#             rows[i]=rows[j]
#             print(f'{i+1} and {j+1} has same values')
